const elasticsearch = require('elasticsearch');

const es = new elasticsearch.Client({
  host: 'https://vpc-covid-help-ggo4aqwgkblo7uh2oxp4izirjy.ap-south-1.es.amazonaws.com/',
  log: 'trace',
  apiVersion: '7.9', // use the same version of your Elasticsearch instance
});
exports.handler = async (event) => {
  es.ping({
    // ping usually has a 3000ms timeout
    requestTimeout: 1000
  }, function (error) {
    if (error) {
      console.trace('elasticsearch cluster is down!');
    } else {
      console.log('All is well');
    }
  });
};